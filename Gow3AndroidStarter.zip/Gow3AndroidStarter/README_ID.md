# GOW3 Android Starter (Milestone A)

## Status jujur

Ini adalah **project Android Studio diagnostik Vulkan**, bukan emulator PS4 dan bukan port God of War III. APK ini belum menjalankan game. Tujuan milestone pertama adalah menguji apakah perangkat Android ARM64 bisa membuat Vulkan instance, mendeteksi GPU, membaca versi API dan beberapa ekstensi penting.

## Cara membuka

1. Ekstrak ZIP ini.
2. Instal Android Studio versi stabil yang mendukung Android Gradle Plugin 8.10.1.
3. Di Android Studio, pilih **Open** dan pilih folder `Gow3AndroidStarter` hasil ekstrak.
4. Saat diminta, instal Android SDK Platform 35, Android SDK Build-Tools, NDK, dan CMake 3.22.1 melalui SDK Manager.
5. Hubungkan HP Android 15+ dengan USB debugging aktif, atau gunakan emulator Android yang mendukung Vulkan (perangkat nyata lebih berguna untuk tes GPU).
6. Tunggu Gradle Sync, lalu tekan **Run**.
7. Tekan tombol **Periksa GPU dan Vulkan**. Salin hasil yang muncul untuk dianalisis pada langkah berikutnya.

> Build pertama membutuhkan koneksi internet untuk mengunduh Gradle/Android Gradle Plugin dan komponen SDK jika belum terpasang.

## Target

- ABI: `arm64-v8a`
- `minSdk = 35`, `targetSdk = 35`
- Kotlin + Android NDK + CMake + Vulkan loader Android
- Tidak membutuhkan file game dan tidak mengirim data ke jaringan

## Batasan penting

- Vulkan probe tidak menguji semua fitur yang dibutuhkan shadPS4.
- Source yang diberikan pengguna menargetkan runtime PS4 pada CPU x86-64 dan jalur desktop Windows/Linux. Android ARM64 membutuhkan investigasi CPU translation dan porting sistem yang signifikan.
- Tidak ada klaim kompatibilitas game, performa, atau target 30 FPS pada milestone ini.

## Catatan audit ZIP sumber

Berdasarkan README dan source yang terlihat dalam ZIP:

- README menyatakan game executable berjalan native pada CPU x86-64 dan runtime menggantikan layanan sistem PS4.
- `gpu/CMakeLists.txt` meminta Vulkan, fmt, Boost, tsl-robin-map, SDL3, FFmpeg, Zydis, shader compiler, dan komponen tambahan.
- CMake menambahkan X11 pada jalur non-Windows; ada juga link library Windows khusus seperti `ws2_32`, `bcrypt`, `ntdll`, `synchronization`, `winmm`, dan `pdh` pada jalur Windows.
- Submodule tercatat di `.gitmodules`; isi submodule tidak otomatis dijamin hadir hanya karena ZIP source tersedia.
- `third_party/xbyak` dipakai di GPU build. Karena Xbyak adalah assembler/JIT yang berorientasi x86/x64, pemakaiannya perlu diaudit sebelum port ARM64.
- Source memerlukan audit tambahan atas semua kode khusus x86-64, ABI, memory mapping, signals, thread, shader toolchain, dan API Android.

## Milestone berikutnya

Setelah APK ini diuji pada HP nyata, hasil GPU/driver/ekstensi dapat dipakai untuk memutuskan apakah ada jalur Vulkan yang layak. Setelah itu audit build harus mencakup submodule, compiler/assembler JIT, dan CPU runtime. Jangan mengintegrasikan seluruh source ke aplikasi Android sebelum dependensi dan jalur ARM64 dipastikan.
