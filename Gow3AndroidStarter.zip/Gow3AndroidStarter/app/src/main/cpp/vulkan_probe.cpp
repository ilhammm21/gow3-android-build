#include <jni.h>
#include <vulkan/vulkan.h>
#include <algorithm>
#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

static std::string versionString(uint32_t v) {
    std::ostringstream s;
    s << VK_API_VERSION_MAJOR(v) << "." << VK_API_VERSION_MINOR(v) << "." << VK_API_VERSION_PATCH(v);
    return s.str();
}

static std::string runProbe() {
    std::ostringstream out;
    uint32_t loaderVersion = VK_API_VERSION_1_0;
    auto enumerateVersion = reinterpret_cast<PFN_vkEnumerateInstanceVersion>(vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion"));
    if (enumerateVersion) {
        VkResult vr = enumerateVersion(&loaderVersion);
        if (vr != VK_SUCCESS) out << "Peringatan: gagal membaca versi Vulkan loader (" << vr << ").\n";
    }
    out << "ABI aplikasi: arm64-v8a\n";
    out << "Vulkan loader API: " << versionString(loaderVersion) << "\n\n";

    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "GOW3 Android Probe";
    app.applicationVersion = 1;
    app.pEngineName = "Compatibility Probe";
    app.engineVersion = 1;
    app.apiVersion = std::min(loaderVersion, static_cast<uint32_t>(VK_API_VERSION_1_3));

    VkInstanceCreateInfo createInfo{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    createInfo.pApplicationInfo = &app;
    VkInstance instance = VK_NULL_HANDLE;
    VkResult result = vkCreateInstance(&createInfo, nullptr, &instance);
    if (result != VK_SUCCESS) {
        out << "HASIL: vkCreateInstance gagal, kode " << result << ".\n";
        out << "Ini hanya tes awal. Periksa driver Vulkan dan versi Android.\n";
        return out.str();
    }

    uint32_t count = 0;
    result = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (result != VK_SUCCESS || count == 0) {
        out << "Tidak ditemukan perangkat Vulkan. Kode: " << result << "\n";
        vkDestroyInstance(instance, nullptr);
        return out.str();
    }
    std::vector<VkPhysicalDevice> devices(count);
    result = vkEnumeratePhysicalDevices(instance, &count, devices.data());
    if (result != VK_SUCCESS) {
        out << "Gagal membaca daftar GPU. Kode: " << result << "\n";
        vkDestroyInstance(instance, nullptr);
        return out.str();
    }

    out << "Jumlah perangkat Vulkan: " << count << "\n\n";
    for (uint32_t i = 0; i < count; ++i) {
        VkPhysicalDeviceProperties props{};
        vkGetPhysicalDeviceProperties(devices[i], &props);
        out << "GPU " << (i + 1) << ": " << props.deviceName << "\n";
        out << "  Vendor ID: 0x" << std::hex << props.vendorID << "\n";
        out << "  Device ID: 0x" << props.deviceID << std::dec << "\n";
        out << "  Driver version (raw): " << props.driverVersion << "\n";
        out << "  Vulkan API GPU: " << versionString(props.apiVersion) << "\n";
        out << "  Max image dimension 2D: " << props.limits.maxImageDimension2D << "\n";
        out << "  Max push constants: " << props.limits.maxPushConstantsSize << " bytes\n";

        uint32_t extCount = 0;
        VkResult er = vkEnumerateDeviceExtensionProperties(devices[i], nullptr, &extCount, nullptr);
        std::vector<VkExtensionProperties> extensions;
        if (er == VK_SUCCESS && extCount > 0) {
            extensions.resize(extCount);
            er = vkEnumerateDeviceExtensionProperties(devices[i], nullptr, &extCount, extensions.data());
        }
        const char* important[] = {
            "VK_KHR_swapchain",
            "VK_KHR_timeline_semaphore",
            "VK_KHR_synchronization2",
            "VK_KHR_dynamic_rendering",
            "VK_KHR_buffer_device_address",
            "VK_EXT_descriptor_indexing",
            "VK_KHR_shader_float16_int8",
            "VK_EXT_memory_budget",
            "VK_KHR_push_descriptor"
        };
        out << "  Ekstensi penting yang ditemukan:\n";
        for (const char* wanted : important) {
            bool found = std::any_of(extensions.begin(), extensions.end(), [wanted](const VkExtensionProperties& e) {
                return std::string(e.extensionName) == wanted;
            });
            out << "    " << (found ? "[ADA]   " : "[TIDAK] ") << wanted << "\n";
        }
        out << "  Total ekstensi device: " << extCount << "\n\n";
    }
    out << "CATATAN: lolos probe Vulkan bukan bukti bahwa runtime PS4 atau game dapat berjalan.\n";
    out << "Probe ini belum menguji fitur Vulkan khusus, binary translation, audio, atau gameplay.\n";
    vkDestroyInstance(instance, nullptr);
    return out.str();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_gow3android_MainActivity_nativeVulkanReport(JNIEnv* env, jobject /* thiz */) {
    try {
        const std::string report = runProbe();
        return env->NewStringUTF(report.c_str());
    } catch (...) {
        return env->NewStringUTF("Probe gagal karena error native yang tidak tertangani.\n");
    }
}
