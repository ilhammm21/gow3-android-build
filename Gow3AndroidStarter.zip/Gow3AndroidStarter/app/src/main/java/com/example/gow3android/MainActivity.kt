package com.example.gow3android

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (resources.displayMetrics.density * 20).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF101820.toInt())
        }
        val title = TextView(this).apply {
            text = "GOW3 Android · Compatibility Probe"
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
        }
        val intro = TextView(this).apply {
            text = "Versi awal diagnostik. Aplikasi ini BELUM menjalankan God of War III. Gunakan tombol di bawah untuk membaca informasi Vulkan dari HP."
            textSize = 15f
            setTextColor(0xFFD5E2EF.toInt())
            setPadding(0, pad / 2, 0, pad)
        }
        val button = Button(this).apply {
            text = "Periksa GPU dan Vulkan"
            setOnClickListener { output.text = nativeVulkanReport() }
        }
        output = TextView(this).apply {
            text = "Belum diperiksa."
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFFB8F7D4.toInt())
            setPadding(0, pad, 0, 0)
        }
        val scroll = ScrollView(this).apply {
            addView(output, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(title)
        root.addView(intro)
        root.addView(button)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private external fun nativeVulkanReport(): String

    companion object {
        init { System.loadLibrary("gow3probe") }
    }
}
